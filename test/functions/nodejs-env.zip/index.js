exports.env = (event, context, callback) => {
	callback(null, process.env);
};
